Balanced Group Randomizer — Manual Local Edition, P05.12 Flexible Seating

Unzip and open BGR-Manual-Local-Edition.html in a modern web browser.

NEW: In Groups, enable Show groups on seating chart. BGR now seats every
present student as long as the saved layout has enough total seats, even if
physical desk clusters don't exactly match the generated group sizes.
Pairs remain pairs; nearby desks may be used for a group that cannot fit at
one table. A warning appears only when there are too few seats. The layout
and permanent seating assignments are never overwritten by Quick Groups.

Still available: Groups / Layout Builder / Teacher Setup, Random student,
attendance controls, Student View and Fullscreen, rules, locks and roles.

Export and verify a JSON backup before upgrading. Class data is browser-
local and is not automatically synced or encrypted by this edition.
Fully offline PDF importing is unavailable; paste names or import a JSON backup.
