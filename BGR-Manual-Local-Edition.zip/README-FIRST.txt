Balanced Group Randomizer — Manual Local P05.14: Compact Groups and Consistent Roles

Open BGR-Manual-Local-Edition.html in a supported browser after unzipping.

New Groups controls: one compact row for Seating Chart, Group Size, Roles, and
Strategy. A short status line and Rebalance present button sit below it. Longer
instructional descriptions no longer occupy the classroom display.

Role rules follow the selected group-size preference:
  Size 2, group of 2:   first person Role 1; second person Role 2.
  Size 2, group of 3:   Roles 1, 2 and 3 (odd-roster trio).
  Size 3, group of 2:   first person Role 1; second person Roles 2 + 3.
  Size 3, group of 3:   Roles 1, 2, 3.
  Size 4, group of 4:   Roles 1, 2, 3, 4.
  Size 4, group of 3:   Roles 1, 2, and Roles 3 + 4 for the third student.
  Size 4, group of 2:   Roles 1, and Roles 2 + 3 + 4 for the second student.

Teacher Setup retains four shared, editable role names. The Roles checkbox
hides and restores role labels without changing group membership. This is a
visual/control update; saved layouts, permanent seating, and the temporary
no-cross-cluster seating behavior from P05.13 remain unchanged.

Export a JSON backup before updating. The manual-only edition uses local browser
storage and JSON backups, not automatic cloud sync. The PowerSchool version is a
separate fictional-data prototype and does not connect to live student records.
