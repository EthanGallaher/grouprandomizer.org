Balanced Group Randomizer — P05.10 manual local edition (2026-11-18)

1. Unzip and open BGR-Manual-Local-Edition.html in a browser.
2. Export and verify a JSON backup before replacing an existing edition.
3. Grouping tab now separates Student View (privacy masking) and Fullscreen (size only).
4. Student View is a visual presentation mode, not authentication or encryption.
5. No cloud sync; all class information persists only in this browser profile.
6. PDF import in manual HTML requires a separately configured supported PDF parser.
