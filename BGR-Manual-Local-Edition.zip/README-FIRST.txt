Open BGR-Manual-Local-Edition.html in a browser. Local storage and JSON backup are not encrypted. No cloud sync. PDF import requires separately approved local PDF.js assets.
