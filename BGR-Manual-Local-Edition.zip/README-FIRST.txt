Balanced Group Randomizer — Manual Local Edition, P05.13 Group Sizes & Desk-Aligned Groups

Unzip and open BGR-Manual-Local-Edition.html in a supported browser.

NEW — Select preferred group size 2, 3, or 4 on the Groups page. Size 4 favors
4, then 3, then 2; size 3 favors 3, then 2; size 2 uses pairs and one trio
when the present student count is odd. Teacher Setup has four shared role labels
(default fourth role: Checker). Use the Groups-page Roles checkbox to turn
role assignments on/off without changing group membership.

Quick Groups seating never splits an on-screen group across physical desk
clusters. Instead, it automatically restructures the temporary groups to fit
available clusters. More than one group can share a four-seat cluster. Switching
back to Group Cards restores the selected group-size priorities, and may
recombine temporary groups. Saved seating assignments are never overwritten.

When only single-seat desks are available, singles are physically unavoidable;
the app explains this as guidance rather than reporting a seat shortage. If
saved Keep Together / Keep Apart rules or locks cannot be honored with the
chosen cluster sizes, a teacher-facing notice identifies the conflict or
released locks. Change the layout/rules when those constraints must remain hard.

Export a JSON backup before upgrading. Data is kept in this browser, without
automatic cross-device sync or encryption. Fully offline PDF importing is
unavailable; paste names or import a JSON backup instead.
