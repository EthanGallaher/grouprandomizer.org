Balanced Group Randomizer — Manual Local Edition, P05.9 Quick Groups

Unzip and open BGR-Manual-Local-Edition.html in a browser.
The Groups tab includes a switch between group cards and a temporary
seating-chart projection of your saved layout. The chosen view does not
overwrite permanent seating chart student assignments.

Export and verify a JSON backup before replacing earlier installations.
Class data is browser-local and not automatically encrypted or synced.
PDF roster importing is unavailable in this fully offline manual edition;
paste names or restore a JSON backup instead.
